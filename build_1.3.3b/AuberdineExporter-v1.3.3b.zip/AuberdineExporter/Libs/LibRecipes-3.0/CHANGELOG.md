# Lib: Recipes

## [v39-release](https://github.com/warmexx/librecipes-3-0/tree/v39-release) (2025-07-26)
[Full Changelog](https://github.com/warmexx/librecipes-3-0/commits/v39-release) [Previous Releases](https://github.com/warmexx/librecipes-3-0/releases)

- Replaces Cataclysm by Mists of Pandaria  
